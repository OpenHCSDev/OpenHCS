# Comprehensive Implementation Plan: Significant Lean 4 Proofs for Decision Quotient Theory

## Executive Summary

This document provides instructions for implementing Lean 4 proofs that elevate Paper 4 from incremental infrastructure to significant contributions. The goal is to establish **novel complexity-theoretic results about decision-theoretic concepts**.

**Target Contributions:**
1. coNP-completeness of sufficiency checking
2. #P-hardness of computing decision quotients
3. Polynomial-time algorithms for tractable special cases
4. Connections to mechanism design and value of information

## Status (Implemented)

- **Sufficiency checking hardness:** Formal coNP-completeness proof via TAUTOLOGY reduction in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Reduction.lean` and summary in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness.lean`.
- **Minimum sufficient set:** Formalized as an $\exists\forall$ property (Σ₂ᴾ upper bound) with a coNP-hard lower bound (the `k=0` case). See `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness.lean` and the manuscript section `docs/papers/paper4_decision_quotient/latex/hardness_proofs.tex`.
- **Anchor sufficiency (fixed coordinates):** Σ₂ᴾ-complete via ∃∀-SAT reduction in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness/AnchorSufficiency.lean`, with manuscript statement in `docs/papers/paper4_decision_quotient/latex/hardness_proofs.tex`.
- **Decision quotient counting complexity:** #P-hardness encoded and recovered in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness/CountingComplexity.lean` and `.../Hardness/ApproximationHardness.lean`.
- **Tractable subcases:** Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/`.
- **Economics / VOI:** Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Economics/`.
- **Build:** `cd docs/papers/paper4_decision_quotient/proofs && /home/ts/.elan/bin/lake build` completes cleanly.

---

## Part 1: Current State Assessment

### Existing Files
```
DecisionQuotient/
├── Basic.lean              -- DecisionProblem, Opt, sufficiency definitions
├── AlgorithmComplexity.lean -- Counted monad, step counting
├── PolynomialReduction.lean -- PolyReduction, composition, InP (✅ COMPILES)
└── (additional files TBD)
```

### What's Already Proven
- `PolyReduction` structure and composition
- `poly_compose_bound` - polynomials close under composition
- `poly_reduction_preserves_P` - P closed under reductions
- `SufficiencyInstance` and `SetComparisonInstance` structures
- Basic reduction skeleton `sufficiencyToSetComparison`

### What's Missing for Significance
- Hardness reductions FROM known hard problems
- Exact complexity characterizations
- Tractability results with proofs
- Connection to economic/information-theoretic quantities

---

## Part 2: Mathematical Foundations to Formalize

### 2.1 Core Definitions Needed

```lean
/-- A decision problem instance with finite, explicit representation -/
structure FiniteDecisionProblem where
  actions : Finset Action
  states : Finset State
  utility : Action → State → ℤ  -- Use ℤ for cleaner arithmetic

/-- The set of optimal actions for a given state -/
def optimalActions (dp : FiniteDecisionProblem) (s : State) : Finset Action :=
  dp.actions.filter (fun a => ∀ a' ∈ dp.actions, dp.utility a s ≥ dp.utility a' s)

/-- Decision Quotient: fraction of actions that are optimal somewhere in equivalence class -/
def decisionQuotient (dp : FiniteDecisionProblem) (states : Finset State) : ℚ :=
  (states.biUnion (optimalActions dp)).card / dp.actions.card

/-- Sufficiency: a coordinate set is sufficient iff it preserves optimal actions -/
def isSufficient (dp : FiniteDecisionProblem) (coords : Finset Coord) : Prop :=
  ∀ s s' : State, (∀ c ∈ coords, s c = s' c) → optimalActions dp s = optimalActions dp s'
```

---

## Part 3: Hardness Results (Path 1 - Most Important)

### 3.1 Target Theorem: coNP-Completeness of Sufficiency Checking

**Implemented in:** `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Reduction.lean`
and `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness.lean`.

**Result:** SUFFICIENCY-CHECK is coNP-complete. The reduction is from TAUTOLOGY
using a reference state plus the empty coordinate set, with correctness proved
in Lean (`tautology_iff_sufficient`). Membership in coNP is formalized via an
insufficiency witness in `DecisionQuotient/Computation.lean`.

### 3.2 Alternative: Reduction from Set Cover

Not pursued in the formalization. The proven lower bound for
MINIMUM-SUFFICIENT-SET is coNP-hard via the $k=0$ case.

---

## Part 4: Counting Complexity (Path 2)

### 4.1 Target Theorem: #P-Hardness of Decision Quotient

Implemented in:
`docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness/CountingComplexity.lean`
and `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness/ApproximationHardness.lean`.
The reduction encodes the count via
\[
\mathrm{DQ} = \frac{\#\mathrm{SAT} + 1}{1 + 2^n},
\]
and the count is recovered algebraically in Lean.

### 4.2 Approximation Hardness

Implemented as a conservative approximation statement: exact computation yields
an ε-approximation for any ε ≥ 0 (see `dq_approximation_hard`).

---

## Part 5: Tractability Results (Path 3)

### 5.1 Polynomial Cases

**Theorem 1: Bounded Actions**
Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/BoundedActions.lean`.

**Theorem 2: Separable Utilities**
Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/SeparableUtility.lean`.

**Theorem 3: Tree-Structured State Spaces**
Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/TreeStructure.lean`.

### 5.2 Fixed-Parameter Tractability

Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/FPT.lean`.


---

## Part 6: Mechanism Design Connection (Path 4)

### 6.1 Value of Information Complexity

Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Economics/ValueOfInformation.lean`
and `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Economics/Approximation.lean`.

### 6.2 Information Elicitation

Implemented in `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Economics/Elicitation.lean`.

---

## Part 7: Technical Implementation Guide

### 7.1 Lean 4 / Mathlib Patterns

**Pattern 1: Defining Complexity Classes**
```lean
import Mathlib.Computability.TuringMachine
import Mathlib.Computability.Reduce

/-- NP defined via polynomial-time verifiers -/
def InNP {α : Type*} [SizeOf α] (p : α → Prop) : Prop :=
  ∃ (verify : α → Certificate → Bool) (c k : ℕ),
    (∀ a cert, verifyTime a cert ≤ c * (sizeOf a + sizeOf cert)^k + c) ∧
    (∀ a, p a ↔ ∃ cert, sizeOf cert ≤ poly (sizeOf a) ∧ verify a cert = true)

/-- Polynomial-time many-one reduction -/
def PolyReduces (A B : Type*) [SizeOf A] [SizeOf B]
    (pA : A → Prop) (pB : B → Prop) : Prop :=
  ∃ (r : PolyReduction A B), ∀ a, pA a ↔ pB (r.f a)

notation:50 p " ≤ₚ " q => PolyReduces _ _ p q
```

**Pattern 2: Finset Computations**
```lean
-- Use Finset for decidable, computable sets
-- Use Decidable instances for computability

instance : DecidableEq Action := inferInstance
instance : Fintype State := inferInstance

def optimalActions (dp : FiniteDecisionProblem) (s : State) : Finset Action :=
  dp.actions.filter (fun a =>
    dp.actions.all (fun a' => dp.utility a s ≥ dp.utility a' s))
```

**Pattern 3: Reduction Proofs**
See `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Reduction.lean`
for the full forward/backward proof pattern.

### 7.2 File Structure

```
DecisionQuotient/
├── Basic.lean                    -- Core definitions
├── AlgorithmComplexity.lean      -- Complexity infrastructure
├── PolynomialReduction.lean      -- Reduction framework
├── Reduction.lean                -- TAUTOLOGY reduction
├── Computation.lean              -- Computable sufficiency checks
├── Hardness.lean                 -- Problem encodings and summaries
├── Hardness/
│   ├── SAT.lean                  -- SAT definitions and basic properties
│   ├── CountingComplexity.lean   -- #P-hardness of DQ
│   └── ApproximationHardness.lean
├── Tractability/
│   ├── BoundedActions.lean       -- Poly-time with bounded |A|
│   ├── SeparableUtility.lean     -- Poly-time for separable utilities
│   ├── TreeStructure.lean        -- Poly-time for tree dependencies
│   └── FPT.lean                  -- Fixed-parameter tractability
├── Economics/
│   ├── ValueOfInformation.lean   -- VOI definitions and complexity
│   ├── Elicitation.lean          -- Mechanism design connections
│   └── Approximation.lean        -- FPTAS results
├── Dichotomy.lean                -- Complexity dichotomy
└── ComplexityMain.lean           -- Imports and summary theorems
```

### 7.3 Key Mathlib Imports

```lean
-- Computability
import Mathlib.Computability.TuringMachine
import Mathlib.Computability.Reduce
import Mathlib.Computability.Primrec

-- Combinatorics (for reductions)
import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic

-- Number theory (for counting)
import Mathlib.Data.Nat.Choose.Sum
import Mathlib.Algebra.BigOperators.Basic

-- Probability (for VOI)
import Mathlib.Probability.ProbabilityMassFunction.Basic
```

---

## Part 8: Prioritized Implementation Order (Completed)

All phases are complete in the current build. Key entry points:
- `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Reduction.lean`
- `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Hardness/CountingComplexity.lean`
- `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Tractability/`
- `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/Economics/`
- `docs/papers/paper4_decision_quotient/proofs/DecisionQuotient/ComplexityMain.lean`

---

## Part 9: Success Criteria

All criteria are met in the current implementation:
- coNP-completeness of SUFFICIENCY-CHECK (TAUTOLOGY reduction)
- #P-style counting reduction for decision quotient (exact extraction)
- Multiple tractability results (bounded actions, separable utility, tree structure, FPT)
- VOI and elicitation connections in the Economics modules

---

## Part 10: Common Pitfalls and Solutions

### Pitfall 1: Nat Arithmetic
**Problem:** `ring` fails, `omega` fails on powers
**Solution:** Use explicit lemmas: `Nat.pow_add`, `Nat.mul_comm`, calc chains

### Pitfall 2: Computability vs Decidability
**Problem:** Confusing `Decidable` (compile-time) with `Computable` (Turing)
**Solution:** Use `Decidable` for finite structures, reference Mathlib's `Computable` for TMs

### Pitfall 3: Finset vs Set
**Problem:** `Set` is not computable, proofs get stuck
**Solution:** Use `Finset` throughout for computational content

### Pitfall 4: Missing Instances
**Problem:** `DecidableEq`, `Fintype` not found
**Solution:** Add explicit instances or use `classical` for non-computational proofs

### Pitfall 5: Size Encoding
**Problem:** Polynomial-time needs size, but what's the encoding?
**Solution:** Define `SizeOf` instances explicitly for all problem types

---

## Appendix: Reference Theorems from Literature

### Complexity Theory
- Cook-Levin: SAT is NP-complete
- Valiant: #SAT is #P-complete
- Set Cover is NP-complete (Karp's 21)

### Decision Theory / Information
- Blackwell's theorem on information ordering
- Value of information bounds (Gittins, etc.)

### Relevant Papers
- "Computational Complexity of Information Acquisition" (various)
- "The Complexity of Agreement" (Aaronson)
- "Computational aspects of decision making" (Papadimitriou et al.)

---

## Final Notes

This plan transforms the current infrastructure into publishable results. The key insight is that **complexity of decision-theoretic concepts** is under-explored, and proving rigorous Lean theorems about it is novel.

The coNP-completeness of sufficiency checking (Part 3) is the **highest priority** - it's the most accessible result that would be genuinely new.

Good luck. The mathematics is sound; the formalization is the challenge.
