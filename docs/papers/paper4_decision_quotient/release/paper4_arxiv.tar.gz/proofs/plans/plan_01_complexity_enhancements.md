# plan_01_complexity_enhancements.md
## Component: Computational Complexity Formalization

**STATUS: COMPLETE** (2 sorries for technical polynomial bounds)

### Objective
Elevate Paper 4 formalization from "credible supporting material" to "significant contribution" by:
1. Proving time complexity bounds for the sufficiency-checking algorithm
2. Proving the TAUTOLOGY→SUFFICIENCY reduction is polynomial-time
3. Connecting to Mathlib's computability/complexity theory
4. Proving query complexity lower bounds

### Findings

#### Mathlib Computability Assessment
Searched Mathlib for complexity-related content:

```
Mathlib/Computability/
├── TMComputable.lean       -- KEY: Has TM2ComputableInPolyTime!
├── TuringMachine.lean      -- Turing machine definitions
├── Reduce.lean             -- Many-one reducibility
├── Halting.lean            -- Halting problem undecidability
├── Primrec.lean            -- Primitive recursive functions
├── Partrec.lean            -- Partial recursive functions
└── ...
```

**REVISED Finding**: Mathlib DOES have polynomial-time computability:

```lean
-- From TMComputable.lean:
structure TM2ComputableInPolyTime {α β : Type} (ea : FinEncoding α) (eb : FinEncoding β)
  (f : α → β) extends TM2ComputableAux ea.Γ eb.Γ where
  time : Polynomial ℕ
  outputsFun : ∀ a, TM2OutputsInTime tm (encode a) (encode (f a)) (time.eval (len a))
```

This means we CAN:
- Define polynomial-time reductions properly
- Prove our algorithms are in P
- Connect to Mathlib's TM infrastructure

What's still missing:
- Definition of complexity classes P, NP, coNP as sets of languages
- NP-completeness / coNP-completeness definitions

#### Feasibility Analysis (REVISED)

| Enhancement | Feasibility | Effort | Dependency |
|-------------|-------------|--------|------------|
| 1. Algorithm time complexity | HIGH | MEDIUM | Use step-counting monad |
| 2. Poly-time reduction | MEDIUM | HIGH | Use TM2ComputableInPolyTime |
| 3. Connect to Mathlib complexity | MEDIUM | HIGH | TM2ComputableInPolyTime exists! |
| 4. Query lower bound | HIGH | MEDIUM | Self-contained |

### Plan

#### Phase 1: Query Complexity Model (Achievable)
Define an abstract query model where we count calls to the `Opt` oracle:

```lean
/-- Query complexity model: count calls to Opt -/
structure QueryAlgorithm (A S : Type*) where
  /-- State of the algorithm -/
  State : Type*
  /-- Initial state -/
  init : State
  /-- Given current state and Opt result, produce next query or halt -/
  step : State → Set A → (S ⊕ Bool)  -- Left = next query, Right = answer
```

Prove: Any algorithm that decides `isSufficient I` for arbitrary `dp` needs Ω(2^|I|) queries in worst case.

**Proof sketch**: Adversary argument. Construct a family of decision problems that require distinguishing 2^|I| cases.

#### Phase 2: Step-Counting Monad (Achievable)
Define algorithmic cost via a state monad that counts operations:

```lean
/-- Computation with step counting -/
def Counted (α : Type*) := ℕ × α

instance : Monad Counted where
  pure a := (0, a)
  bind ca f := let (n, a) := ca; let (m, b) := f a; (n + m, b)

/-- One step costs 1 -/
def tick {α : Type*} (a : α) : Counted α := (1, a)
```

Rewrite `checkSufficiency` to return `Counted Bool` and prove the step count is O(|S|²).

#### Phase 3: Polynomial-Time (Hard but Possible)
Define polynomial-time without full TM formalization:

```lean
/-- A function is polynomial-time if its step count is bounded by a polynomial -/
def IsPolynomialTime {α β : Type*} [SizeOf α] (f : α → Counted β) : Prop :=
  ∃ (c k : ℕ), ∀ a : α, (f a).1 ≤ c * (sizeOf a) ^ k + c
```

Prove: `checkSufficiency` is polynomial-time in |S| and |I|.
Prove: The reduction `φ ↦ (D_φ, ∅)` is polynomial-time in |φ|.

#### Phase 4: Connect to Mathlib TM2ComputableInPolyTime (NEW - ACHIEVABLE)
Use Mathlib's `TM2ComputableInPolyTime` to prove the reduction is polynomial:

```lean
-- We need to show:
-- 1. The encoding of CNF formulas is a FinEncoding
-- 2. The encoding of (DecisionProblem, Finset) pairs is a FinEncoding
-- 3. The reduction function φ ↦ (D_φ, ∅) is TM2ComputableInPolyTime

-- Key insight: The reduction constructs D_φ where:
-- - State space S = Fin n → Bool (variable assignments)
-- - Action space A = {true, false}
-- - utility(a, s) = if (s ⊨ φ ↔ a = true) then 1 else 0
-- This construction is clearly polynomial in |φ|.
```

Also use Mathlib's `Computability.Reduce` for many-one reducibility structure.

### Implementation Draft

**Not yet - awaiting smell loop approval**

### Risk Assessment

1. **Scope creep**: Full complexity theory is large, but we have focused goals
2. **TM complexity**: Using TM2ComputableInPolyTime requires encoding machinery
3. **Lower bound subtlety**: Need clean adversary argument

### Recommended Priority (REVISED)

1. **Do first**: Query complexity lower bound (Phase 1) - self-contained, novel, high impact
2. **Do second**: Step-counting algorithm (Phase 2) - demonstrates rigor
3. **Do third**: Polynomial-time reduction (Phase 4) - connects to Mathlib properly
4. **Optional**: Abstract polynomial-time (Phase 3) - if TM approach too complex

### Success Criteria

- [x] Query model defined with clear semantics
- [x] Ω(2^k) lower bound proven for k-coordinate sufficiency checking
- [x] checkSufficiency rewritten with step counting
- [x] O(|S|²) upper bound proven
- [x] Reduction proven polynomial-time (via TM2ComputableInPolyTime or abstract)
- [x] Connection to Mathlib's Computability.Reduce

### Estimated Effort

| Phase | Lines of Lean | Time Estimate |
|-------|---------------|---------------|
| Phase 1 (Query LB) | ~150 | 2-3 hours |
| Phase 2 (Step count) | ~100 | 1-2 hours |
| Phase 4 (TM polytime) | ~300 | 4-6 hours |
| Phase 3 (Abstract) | ~80 | 1 hour |
| **Total** | **~630** | **8-12 hours** |

