# plan_03_sigma2p_completeness_bruteforce.md
## Component: Σ₂ᴾ-Completeness of MINIMUM-SUFFICIENT-SET

**STATUS: EXPLORATION - Hand to capable agent for systematic attack**

---

## The Problem

Prove or disprove: MINIMUM-SUFFICIENT-SET is Σ₂ᴾ-complete.

**What we have:**
- MSS ∈ Σ₂ᴾ (by quantifier structure ∃I∀s∀s')
- MSS is coNP-hard (k=0 case)
- ANCHOR-SUFFICIENCY is Σ₂ᴾ-hard (proven in AnchorSufficiency.lean)

**What we need:**
- MSS is Σ₂ᴾ-hard (reduction from ∃∀-SAT or another Σ₂ᴾ-complete problem)

---

## First Principles Analysis

### The Structural Mismatch

```
∃∀-SAT:  ∃x ∈ {0,1}^m  ∀y ∈ {0,1}^k : φ(x,y) = 1
MSS:     ∃I ⊆ {1..n}   ∀s,s' ∈ S   : agreeOn(s,s',I) → Opt(s) = Opt(s')
```

| Aspect | ∃∀-SAT | MSS |
|--------|--------|-----|
| Existential object | Assignment x | Subset I |
| Universal check | Single formula eval per y | Pairwise Opt equality |
| Structure | Find ONE good x | Find ONE good I |

### The Core Obstacle

When I = {x-coordinates}, sufficiency becomes:
```
∀s,s': same x → same Opt
```
This is: **∀x: Opt(x,·) is y-constant**

We WANT: **∃x: ∀y: φ(x,y) = 1**

The ∀x vs ∃x mismatch is fundamental.

### The Key Insight

The choice of I must ENCODE the existential witness x.

If different I's correspond to different x's, then:
- "∃I: I is sufficient" becomes "∃x: [x's I] is sufficient"
- We need: "[x's I] is sufficient ⟺ ∀y: φ(x,y) = 1"

---

## Attack Vectors

### VECTOR 1: I-Encodes-x via Gadget Pairs

**Construction:**
```
Coordinates: 2m + k total
  - Pairs (c₁⁰, c₁¹), (c₂⁰, c₂¹), ..., (cₘ⁰, cₘ¹)  -- m pairs
  - y-coordinates y₁, ..., yₖ

Valid I: picks exactly one from each pair, |I| = m
  - I = {c₁^{x₁}, ..., cₘ^{xₘ}} encodes x

State space: {0,1}^{2m+k}
```

**The Challenge:** Design Opt such that:
```
I_x is sufficient ⟺ ∀y: φ(x,y) = 1
```

**Constraint derivation:**
For I_x to be sufficient:
∀s,s': agreeOn(s,s',I_x) → Opt(s) = Opt(s')

States s,s' agree on I_x iff: for all i, s(cᵢ^{xᵢ}) = s'(cᵢ^{xᵢ})

This says nothing about:
- The "other" c-coordinates (cᵢ^{1-xᵢ})
- The y-coordinates

So Opt must be constant on equivalence classes that can differ on y.

**Critical observation:** For I_x to be sufficient, Opt(s) can only depend on the SELECTED coordinates {cᵢ^{xᵢ}}, not on y or unselected c's.

But φ(x,y) depends on both x AND y. How can y-dependence vanish exactly when ∀y:φ(x,y)=1?

**Potential mechanism:**
```lean
U(YES, s) := if (extracted_x(s) = encoded_x(s) ∧ φ(extracted_x(s), y(s))) then 2 else 0
U(NO, s)  := 1
```
Where:
- extracted_x(s) reads x from the c-coordinates in a specific way
- encoded_x(s) reads x differently
- When they match AND φ=1, YES wins; otherwise NO wins or ties

The idea: I_x being sufficient should force extracted = encoded = x, collapsing y-dependence.

### VECTOR 2: Lift ANCHOR-MSS to MSS

**Observation:** We proved ANCHOR-SUFFICIENCY is Σ₂ᴾ-hard for FIXED I.

ANCHOR-MSS: ∃I (|I|≤k): I is anchor-sufficient
MSS: ∃I (|I|≤k): I is fully-sufficient

**Strategy:** Modify construction so that:
1. Only ONE set I* of size ≤ k can possibly be sufficient
2. For I*, anchor-sufficient ⟺ fully-sufficient
3. Then ANCHOR-MSS ⟺ MSS on this instance

**How to force unique I*:**
Add "poison" coordinates that break any I ≠ I*.

**How to make anchor ⟺ full for I*:**
Ensure all equivalence classes under I* have the same "structure" so one being constant implies all are.

### VECTOR 3: Reduction from Different Σ₂ᴾ-complete Problem

∃∀-SAT isn't the only Σ₂ᴾ-complete problem. Consider:

- **Σ₂-SAT** (same as ∃∀-SAT)
- **MIN-EQUIV**: Is there a formula of size ≤ k equivalent to φ?
- **SHORT-PROOF**: Does φ have a proof of length ≤ k? (for certain proof systems)

Maybe one of these maps more naturally to MSS.

### VECTOR 4: Prove MSS is NOT Σ₂ᴾ-hard

If all construction attempts fail, consider:
- Is MSS in a smaller class? (coNP ⊂ Σ₂ᴾ, could MSS be coNP-complete?)
- Is there a structural reason it can't be Σ₂ᴾ-hard?

**Intuition for why MSS might be "easier":**
The sufficiency condition is SYMMETRIC and TRANSITIVE over equivalence classes.
This structure might make it collapse to coNP.

---

## Systematic Exploration Protocol

### Phase 1: Vector 1 Deep Dive

**Task 1.1:** Formalize the gadget-pair construction in Lean
```lean
def gadgetCoords (m k : ℕ) := Fin (2 * m + k)
def isPair (i : Fin (2*m)) : Bool := i.val % 2 = 0  -- c⁰ coordinates
def partner (i : Fin (2*m)) : Fin (2*m) := ⟨i.val ^^^ 1, ...⟩

def validI (I : Finset (Fin (2*m+k))) (m : ℕ) : Prop :=
  I.card = m ∧ ∀ i : Fin m, (c i 0 ∈ I) ↔ (c i 1 ∉ I)

def encodedX (I : Finset (Fin (2*m+k))) : Fin m → Bool :=
  fun i => c i 1 ∈ I  -- xᵢ = 1 iff we picked cᵢ¹
```

**Task 1.2:** Try Opt designs systematically

Design A: Direct encoding
```lean
def OptA (s : State) : Set Action :=
  if φ(extractX s, extractY s) then {YES} else {NO}
```
Problem: Opt(s) depends on y, so no I is sufficient unless φ is x-constant.

Design B: Conditional on matching
```lean
def extractFromSelected (s : State) (I : Finset Coord) : Assignment := ...
def extractFromState (s : State) : Assignment := ... -- from c¹ coords

def OptB (s : State) : Set Action :=
  if ∀ I, extractFromSelected s I = extractFromState s → φ(...) then {YES} else {NO}
```
Problem: Opt can't depend on I.

Design C: Use "mode" coordinates
```lean
-- State has extra coordinates encoding which I to test
-- But then I isn't being searched, it's being read from state
```

**Task 1.3:** Identify the precise obstruction

Write a Lean theorem characterizing when Vector 1 CAN work:
```lean
theorem vector1_works_iff :
  ∃ (Opt : State → Set Action),
    ∀ x : Assignment m,
      (I_x is sufficient for Opt) ↔ (∀ y, φ x y) :=
  ⟨Opt, proof⟩
```

If this has no proof, the obstruction is:
```lean
theorem vector1_obstruction :
  ¬ ∃ (Opt : State → Set Action),
    ∀ x : Assignment m,
      (I_x is sufficient for Opt) ↔ (∀ y, φ x y) := by
  intro ⟨Opt, h⟩
  -- derive contradiction
  sorry
```

### Phase 2: Vector 2 Deep Dive

**Task 2.1:** Modify QBF construction to force unique sufficient I

Add coordinates d₁, ..., dₙ with:
```lean
U(YES, s) := if s(d₁) = ... = s(dₙ) = 0 then [original U] else -∞
U(NO, s) := if s(d₁) = ... = s(dₙ) = 0 then [original U] else 0
```
This makes any I including a d-coordinate insufficient (Opt varies based on that d).

**Task 2.2:** Prove anchor ⟺ full for our specific I*

For I* = xCoords:
- Equivalence classes are {(x, y) : y ∈ {0,1}^k} for each x
- Anchor: ∃x such that Opt(x,·) is constant
- Full: ∀x, Opt(x,·) is constant

These are different in general. But maybe our construction has special structure?

**Task 2.3:** If anchor ≠ full, try hybrid problem

ANCHOR-MSS is Σ₂ᴾ-hard. If we can show ANCHOR-MSS = MSS on our instances, done.

### Phase 3: Alternative Problems

**Task 3.1:** Study MIN-EQUIV reduction feasibility

MIN-EQUIV: ∃ formula ψ (|ψ| ≤ k): ψ ≡ φ

This has the same ∃ over "structural choices" flavor as MSS.

**Task 3.2:** Study SUCCINCT-SET-COVER reduction

SUCCINCT-SET-COVER is Σ₂ᴾ-complete. The "set" structure might map to coordinate sets.

### Phase 4: Negative Result

**Task 4.1:** Try to prove MSS ∈ coNP

If MSS is in coNP, it's coNP-complete (we have hardness).

For coNP membership, need: "no sufficient I of size ≤k" has poly-size certificate.

Certificate attempt: For each I of size ≤k, a witness pair (s,s') with agree but Opt differs.

Problem: There are C(n,k) such I's, possibly exponential.

But maybe a SINGLE set of witness pairs covers all I's?

**Task 4.2:** Use covering lower bound

We proved: Any poly-size witness set P fails to cover all I's for adversarial Opt.

But this doesn't mean MSS is NOT in coNP - just that THIS certificate approach fails.

---

## Invariants the Successful Construction Must Satisfy

1. **Encoding Invariant:** ∃ bijection between valid I's of size k and x-assignments
2. **Sufficiency Invariant:** I_x sufficient ⟺ ∀y: φ(x,y) = 1
3. **Uniqueness Invariant:** Only the I's corresponding to x-assignments are candidates
4. **Polynomial Invariant:** Construction is poly-time in |φ|

If ANY construction satisfies all four, MSS is Σ₂ᴾ-hard.
If we can prove no construction satisfies all four, MSS is NOT Σ₂ᴾ-hard.

---

## Implementation Skeleton

Create `DecisionQuotient/Hardness/Sigma2PHardness.lean`:

```lean
import DecisionQuotient.Hardness.QBF
import DecisionQuotient.Hardness.AnchorSufficiency

/-! # Σ₂ᴾ-Hardness of MINIMUM-SUFFICIENT-SET

  This file attempts to prove MSS is Σ₂ᴾ-hard by reducing from ∃∀-SAT.
-/

namespace Sigma2PHardness

-- Gadget pair encoding
def GadgetState (m k : ℕ) := Fin (2 * m + k) → Bool

def cCoord (m : ℕ) (i : Fin m) (b : Bool) : Fin (2 * m) :=
  ⟨2 * i.val + if b then 1 else 0, by omega⟩

def yCoord (m k : ℕ) (j : Fin k) : Fin (2 * m + k) :=
  ⟨2 * m + j.val, by omega⟩

def validI (m : ℕ) (I : Finset (Fin (2 * m))) : Prop :=
  I.card = m ∧ ∀ i : Fin m, (cCoord m i false ∈ I) ↔ (cCoord m i true ∉ I)

def encodeX (m : ℕ) (I : Finset (Fin (2 * m))) (hI : validI m I) : Fin m → Bool :=
  fun i => cCoord m i true ∈ I

-- The Opt function to be designed
-- START HERE: Try different definitions
def mssOpt (φ : ExistsForallCNF) (s : GadgetState φ.nx φ.ny) : Set MSSAction :=
  sorry  -- YOUR CONSTRUCTION HERE

-- The main theorem to prove
theorem mss_sigma2p_hard (φ : ExistsForallCNF) :
    ExistsForallCNF.satisfiable φ ↔
      ∃ I : Finset (Fin (2 * φ.nx + φ.ny)),
        validI φ.nx I ∧ isSufficient (mssOpt φ) I :=
  sorry

end Sigma2PHardness
```

---

## Success Criteria

- [ ] `mssOpt` defined without sorry
- [ ] `mss_sigma2p_hard` proven without sorry
- [ ] OR: `mss_not_sigma2p_hard` proven with clear obstruction

---

## Heuristics for the Exploring Agent

1. **When stuck on Opt design:** Write out what Opt(s) must equal for specific states. Work backwards from the equivalence.

2. **When equivalence fails one direction:** Identify the exact counterexample. Use it to refine Opt.

3. **When both directions fail:** The current encoding might be wrong. Try different I ↔ x correspondence.

4. **When all encodings fail:** Consider that MSS might genuinely be easier than Σ₂ᴾ-hard. Pivot to proving negative result.

5. **Use Lean's type checker:** Write the theorem statement first. Let type errors guide you to the right definitions.

---

## Meta-Note for Executing Agent

This is a research problem, not a routine formalization. Success is not guaranteed. However:

- The problem IS well-posed
- A solution WOULD be publishable
- The systematic approach above covers the known attack surface
- First principles reasoning should guide discovery

If you find the obstruction, document it precisely. That's also a result.

Good hunting.

