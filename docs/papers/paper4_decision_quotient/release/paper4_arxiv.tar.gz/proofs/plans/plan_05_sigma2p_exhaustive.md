# plan_05_sigma2p_exhaustive.md
## Component: Exhaustive Attack on MSS Σ₂ᴾ-Completeness

**STATUS: COMPLETE — NEGATIVE SUCCESS (coNP-complete)**

---

## Objective

Either prove MSS is Σ₂ᴾ-hard, or prove it CANNOT be Σ₂ᴾ-hard with documented obstruction.

**Current state:**
- MSS ∈ Σ₂ᴾ ✅ (proven)
- MSS is coNP-hard ✅ (proven)  
- ANCHOR-SUFFICIENCY is Σ₂ᴾ-hard ✅ (proven)
- Gadget-pair encoding fails ❌ (obstruction proven: `vector1_obstruction`)

**Gap:** Σ₂ᴾ-hardness of MSS itself

---

## Known Obstruction (UNIVERSAL)

```lean
theorem sufficient_contains_relevant {A : Type*} {S : Type*} {n : ℕ}
    [CoordinateSpace S n]  -- NOTE: Any coordinate space, not just Bool!
    (dp : DecisionProblem A S) (I : Finset (Fin n))
    (hI : dp.isSufficient I) (i : Fin n) (hi : dp.isRelevant i) :
    i ∈ I
```

**Implication:** On ANY ProductSpace, sufficiency = superset of relevant set.
This is a logical consequence of the definitions, independent of coordinate types.

**RESOLUTION: All escape routes blocked.**
1. ❌ Non-Boolean coordinate spaces — obstruction applies to all ProductSpaces
2. ❌ Encoding via relevant-set SIZE — quantifier structure mismatch
3. ❌ Reductions from other Σ₂ᴾ sources — target is coNP, can't receive Σ₂ᴾ
4. ✅ Proving MSS is actually easier (coNP-complete) — **THIS IS THE ANSWER**

---

## Attack Vectors

### VECTOR A: Relevant-Set Size Encoding

**STATUS: ❌ BLOCKED**

**Core Idea:** Instead of I_x sufficient ⟺ predicate(x), use:
```
|relevant_set(Opt)| ≤ k  ⟺  ∃x∀y: φ(x,y)
```

**Why this DOESN'T work:**

The size encoding collapses to a simple structure. MSS asks:
```
∃I(|I|≤k): I sufficient
```

But by `mss_equiv_relevant_card`:
```
(∃I, |I|≤k ∧ sufficient(I)) ⟺ |relevant_set| ≤ k
```

So MSS = "is the relevant set small?" This is already a SIZE check.

**The fundamental obstruction:** Relevance is defined as:
```
i is relevant ⟺ ∃s,s' differing only at i: Opt(s) ≠ Opt(s')
```

This is an EXISTENTIAL condition. The relevant set is determined by:
```
{i : ∃s,s': ...}
```

To encode ∃x∀y:φ(x,y) in |relevant|, we need:
- Coord yⱼ irrelevant ⟺ ∃x: something
- But irrelevant = ∀s,s': Opt(s) = Opt(s') (UNIVERSAL)

The quantifier structure doesn't match. We cannot make "∃x∀y:φ" control
a universally-quantified irrelevance condition.

**Sub-approach A.2 fails:** Indicator gadgets require 2^m coordinates (exponential).
This is not a poly-time reduction.

**Completion Criteria A:**
- [x] Analysis complete: size encoding blocked by quantifier mismatch
- [ ] Proof: ∃x∀y:φ → |relevant| ≤ k
- [ ] Proof: ¬∃x∀y:φ → |relevant| > k
- [ ] Full theorem: MSS Σ₂ᴾ-hard via this reduction

---

### VECTOR B: Non-Boolean Coordinate Spaces

**STATUS: ❌ BLOCKED**

**Core Idea:** The obstruction theorem is for `Fin n → Bool`. Use larger alphabets.

**Why this DOESN'T work:** The theorem `sufficient_contains_relevant` is proven for
ANY `CoordinateSpace S n`, not just Boolean. The proof is purely logical:

```lean
theorem sufficient_contains_relevant (dp : DecisionProblem A S)
    (I : Finset (Fin n)) (hI : dp.isSufficient I) (i : Fin n) (hi : dp.isRelevant i) :
    i ∈ I := by
  by_contra h_not_in
  obtain ⟨s, s', hdiff, hopt⟩ := hi  -- witness for relevance
  have hagree : agreeOn s s' I := fun j hj => hdiff j (fun heq => h_not_in (heq ▸ hj))
  exact hopt (hI s s' hagree)  -- contradiction
```

The argument:
1. Assume i ∉ I (sufficient set)
2. Since i is relevant, ∃s,s' differing only at i with Opt(s) ≠ Opt(s')
3. Since s,s' differ only at i and i ∉ I, they agree on I
4. By sufficiency: Opt(s) = Opt(s'), contradicting step 2

**This uses NOTHING about coordinate types.** The obstruction is algebraic, not topological.

**Formal closure:** See `Sigma2PExhaustive/Summary.lean`:
```
#check @DecisionProblem.sufficient_contains_relevant
-- Type: ∀ {A S : Type*} {n : ℕ} [CoordinateSpace S n] ...
-- Note: CoordinateSpace, not Bool. Universal obstruction.
```

**Completion Criteria B:**
- [x] Boolean theorem tested on general spaces: **GENERALIZES**
- [x] Vector closed: non-Boolean coordinates do NOT escape the obstruction

---

### VECTOR C: Lift from ANCHOR-MSS

**STATUS: ❌ BLOCKED**

**Core Idea:** ANCHOR-SUFFICIENCY is Σ₂ᴾ-hard. Reduce ANCHOR-MSS to MSS.

**Why this DOESN'T work:**

MSS is coNP-complete (proven). ANCHOR-SUFF is Σ₂ᴾ-hard (proven).

If we could reduce ANCHOR-MSS to MSS, we would have:
```
Σ₂ᴾ-hard problem ≤_p coNP-complete problem
```

This implies Σ₂ᴾ ⊆ coNP, which collapses the polynomial hierarchy.
Under standard complexity assumptions (PH doesn't collapse), no such reduction exists.

**The structural reason:** ANCHOR and regular sufficiency are genuinely different:
```
MSS-SUFF(I):    ∀s,s': agree(s,s',I) → Opt(s) = Opt(s')    [UNIVERSAL]
ANCHOR-SUFF(I): ∃s₀ ∀s: agree(s,s₀,I) → Opt(s) = Opt(s₀)  [∃∀ structure]
```

MSS-SUFF is semantically simpler (collapses to superset-of-relevant).
ANCHOR-SUFF retains the ∃∀ structure that enables hardness.

**Completion Criteria C:**
- [x] Blocked: reducing from Σ₂ᴾ to coNP would collapse PH

---

### VECTOR D: Alternative Source Problems

**STATUS: ❌ BLOCKED**

**Core Idea:** ∃∀-SAT might not be the right source. Try others.

**Why this DOESN'T work:**

The target (MSS) is coNP-complete. ANY Σ₂ᴾ-complete source problem would require:
```
Σ₂ᴾ-complete ≤_p coNP-complete
```

This is impossible under standard assumptions (PH doesn't collapse).

The issue is NOT the source problem. The issue is the TARGET:
MSS is too easy (coNP) to encode Σ₂ᴾ-hard problems.

**Completion Criteria D:**
- [x] Blocked: no Σ₂ᴾ source can reduce to coNP target

---

### VECTOR E: Prove MSS is coNP-complete (Negative Success)

**STATUS: ✅ COMPLETE**

See `VectorE_CoNP.lean` and `Summary.lean`.

**Result:** MSS is coNP-complete.
- coNP-hard: reduction from UNSAT (proven earlier)
- coNP membership: certificate for NO is k+1 relevant coords with witnesses

**Key theorem:**
```lean
theorem mss_equiv_relevant_card {A : Type*} {n : ℕ}
    (dp : DecisionProblem A (Fin n → Bool)) (k : ℕ) :
    (∃ I : Finset (Fin n), I.card ≤ k ∧ dp.isSufficient I) ↔
      (relevantFinset dp).card ≤ k
```

**Completion Criteria E:**
- [x] Formalize collapse theorem
- [x] Prove MSS ∈ coNP
- [x] Document in Summary.lean

---

## Final Resolution

**Outcome: NEGATIVE SUCCESS — MSS is coNP-complete**

| Vector | Status | Reason |
|--------|--------|--------|
| A | ❌ Blocked | Size IS relevant-set cardinality; quantifier mismatch |
| B | ❌ Blocked | Obstruction applies to ALL ProductSpaces, not just Bool |
| C | ❌ Blocked | Would require Σ₂ᴾ ≤ coNP, collapsing PH |
| D | ❌ Blocked | Same as C — target is coNP |
| E | ✅ Success | MSS = |relevant| ≤ k, which is in coNP |

**Formal artifacts:**
- `VectorE_CoNP.lean`: `mss_equiv_relevant_card` theorem
- `Summary.lean`: Vector status documentation, `vectorB_blocked`

**Paper implication:**
- MSS (regular sufficiency): coNP-complete
- ANCHOR-MSS (anchor sufficiency): Σ₂ᴾ-complete (different problem)

---

## Lean Implementation Structure

Implemented in `DecisionQuotient/Hardness/Sigma2PExhaustive/`:

```
Sigma2PExhaustive/
├── VectorE_CoNP.lean   -- Main result: mss_equiv_relevant_card
└── Summary.lean        -- Status documentation, vectorB_blocked
```

---

## Success Criteria (RESOLVED)

**✅ Vector E yields: `theorem mss_equiv_relevant_card` (coNP-complete)**

---

## Final Results Summary

```
SUFFICIENCY-CHECK:    coNP-complete ✅
MSS (size ≤ k):       coNP-complete ✅ (RESOLVED)
ANCHOR-SUFFICIENCY:   Σ₂ᴾ-hard ✅
ANCHOR-MSS:           Σ₂ᴾ-complete (follows from ANCHOR-SUFF hardness)

Key insight: Regular sufficiency is "too strong" — it collapses to superset-of-relevant.
Anchor sufficiency retains ∃∀ structure, enabling hardness.
```

---

## Appendix: Formal Obstruction Statement

```lean
-- From Sigma2PHardness.lean
theorem vector1_obstruction :
    ¬ ∃ dp : DecisionProblem Bool (GadgetState 2 1),
      ∀ x : Fin 2 → Bool,
        dp.isSufficient (I_of_x 2 1 x) ↔ goodEq x

-- Interpretation: You cannot make sufficiency of I_x encode arbitrary predicate on x
-- Specifically tested: goodEq x = (x₀ = x₁), a simple equality predicate
-- Even this simple predicate cannot be encoded via sufficiency on Boolean cubes
```

This obstruction was initially thought to be specific to Boolean coordinates, but analysis
shows it applies universally to all ProductSpaces. See `sufficient_contains_relevant`.

**All escape routes are now blocked.** MSS is coNP-complete.
