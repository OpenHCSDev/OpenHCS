# plan_02_covering_lower_bound.md
## Component: Covering Argument Lower Bound (NOT coNP)

### Objective

Formalize a lower bound showing MINIMUM-SUFFICIENT-SET is NOT in coNP (unless PH 
collapses). The core claim: for adversarial Opt functions, any certificate proving 
"no k-sufficient set exists" requires exponentially many state pairs.

### Plan

#### 1. Define Certificate Structure

A "refutation certificate" for MINIMUM-SUFFICIENT-SET consists of:
- For each candidate set I with |I| ≤ k, a witness pair (s, s') such that:
  - s and s' agree on I (agreeOn s s' I)
  - Opt(s) ≠ Opt(s')

This pair "witnesses" that I is NOT sufficient.

#### 2. Define Covering Relation

A pair (s, s') with Opt(s) ≠ Opt(s') "covers" all candidate sets I where agreeOn s s' I.
Equivalently, I ⊆ Agree(s, s') where Agree(s, s') = {i : s i = s' i}.

Key insight: one pair can refute multiple candidate sets simultaneously.

#### 3. State the Combinatorial Lower Bound

**Theorem (Covering Lower Bound):**
For n coordinates, k = n/2, and any set P of pairs from {0,1}^n × {0,1}^n:
If |P| ≤ poly(n), then there exists a set I with |I| = k such that no pair in P covers I.

**Proof sketch:**
- Number of candidate sets: C(n, k) ≈ 2^n / √n for k = n/2
- A pair (s, s') differing in d coordinates covers sets I ⊆ Agree(s, s')
- |Agree(s, s')| = n - d
- Number of k-subsets of Agree(s, s'): C(n-d, k)
- For d ≥ n/2, this is at most C(n/2, n/2) = 1
- Union bound: poly(n) pairs cover at most poly(n) × max_coverage = poly(n) sets
- But there are 2^Ω(n) candidate sets → most are uncovered

#### 4. Construct Adversarial Opt

Given uncovered set I, construct Opt such that:
- I is NOT sufficient (there exist s, s' with agreeOn I but Opt(s) ≠ Opt(s'))
- All pairs in P fail to witness this

Construction:
- Pick s₀, s₁ that agree on I but differ elsewhere
- Set Opt(s₀) = 0, Opt(s₁) = 1
- Extend arbitrarily to other states

#### 5. Lean File Structure

Create `DecisionQuotient/Hardness/CoveringLowerBound.lean`:

```lean
-- Definitions
def agreementSet (s s' : Fin n → Bool) : Finset (Fin n)
def covers (s s' : Fin n → Bool) (I : Finset (Fin n)) : Prop
def coveringPairs (P : Finset ((Fin n → Bool) × (Fin n → Bool))) 
    (I : Finset (Fin n)) : Prop

-- Core combinatorial lemma
theorem coverage_bound (n k : ℕ) (s s' : Fin n → Bool) :
    (Finset.filter (fun I => covers s s' I ∧ I.card = k) 
      (Finset.powerset Finset.univ)).card ≤ Nat.choose (agreementSet s s').card k

-- Main lower bound
theorem exists_uncovered_set (n : ℕ) (hn : 4 ≤ n)
    (P : Finset ((Fin n → Bool) × (Fin n → Bool)))
    (hP : P.card ≤ n ^ 3) :
    ∃ I : Finset (Fin n), I.card = n / 2 ∧ ∀ p ∈ P, ¬covers p.1 p.2 I

-- Adversarial Opt construction
noncomputable def adversarialOpt (I : Finset (Fin n)) 
    (hI : I.card < n) : (Fin n → Bool) → Bool

-- Main theorem
theorem not_in_coNP_certificate (n : ℕ) (hn : 4 ≤ n)
    (P : Finset ((Fin n → Bool) × (Fin n → Bool)))
    (hP : P.card ≤ n ^ 3) :
    ∃ Opt : (Fin n → Bool) → Bool,
      (∀ I : Finset (Fin n), I.card ≤ n / 2 → ¬isSufficient Opt I) ∧
      (∀ p ∈ P, ∀ I : Finset (Fin n), 
        agreeOn p.1 p.2 I → Opt p.1 = Opt p.2)
```

### Findings

**Existing infrastructure (from codebase review):**
- `agreeOn` defined in `Sufficiency.lean` for CoordinateSpace S n
- `isSufficient` defined as ∀ s s', agreeOn s s' I → dp.Opt s = dp.Opt s'
- For the lower bound, we work directly with `Fin n → Bool` (binary strings)
- Need to bridge: CoordinateSpace instance for `Fin n → Bool`

**Mathlib dependencies needed:**
- `Mathlib.Combinatorics.SimpleGraph.Basic` or direct Finset lemmas
- `Mathlib.Data.Nat.Choose.Basic` for binomial coefficient bounds
- `Mathlib.Data.Finset.Powerset` for set enumeration

**Key proof obligations:**
1. Counting lemma: |{I : |I| = k, I ⊆ S}| = C(|S|, k)
2. Union bound over P
3. C(n, n/2) > n^c for any constant c (exponential growth)
4. Existence of uncovered I
5. Construction of adversarial Opt witnessing the gap

### Implementation Draft

(To be written after smell gate approval)

---

## Detailed Implementation Steps (for autonomous agent)

### Step 1: Create file skeleton

Create `DecisionQuotient/Hardness/CoveringLowerBound.lean` with imports:
```lean
import DecisionQuotient.Basic
import DecisionQuotient.Sufficiency
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Card
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Fin.Basic
import Mathlib.Tactic.Linarith
```

### Step 2: Define BinaryState and agreement

```lean
abbrev BinaryState (n : ℕ) := Fin n → Bool

instance : CoordinateSpace (BinaryState n) n where
  Coord := fun _ => Bool
  proj := fun s i => s i

def agreementSet (s s' : BinaryState n) : Finset (Fin n) :=
  Finset.univ.filter fun i => s i = s' i

lemma agreeOn_iff_subset_agreementSet (s s' : BinaryState n) (I : Finset (Fin n)) :
    agreeOn s s' I ↔ I ⊆ agreementSet s s'
```

### Step 3: Define covering

```lean
def covers (s s' : BinaryState n) (I : Finset (Fin n)) : Prop :=
  I ⊆ agreementSet s s'

lemma covers_iff_agreeOn (s s' : BinaryState n) (I : Finset (Fin n)) :
    covers s s' I ↔ agreeOn s s' I
```

### Step 4: Counting lemma

```lean
lemma count_covered_sets (s s' : BinaryState n) (k : ℕ) :
    (Finset.powersetCard k (agreementSet s s')).card =
      Nat.choose (agreementSet s s').card k
```

### Step 5: Coverage bound per pair

Key insight: a pair (s, s') covers at most C(|Agree(s,s')|, k) sets of size k.
For the worst case (s = s'), this is C(n, k). But we need the opposite bound.

```lean
lemma coverage_per_pair (s s' : BinaryState n) (k : ℕ) :
    (Finset.powersetCard k Finset.univ |>.filter (covers s s')).card ≤
      Nat.choose (agreementSet s s').card k
```

### Step 6: Key observation for lower bound

The naive union bound gives: covered ≤ |P| × C(n, k) which is too weak.

**Refined approach:** Use a probabilistic/counting argument.
- There are C(n, n/2) candidate sets
- Each pair covers C(agree_size, n/2) sets
- For a random pair, E[agree_size] = n/2
- But even with agree_size = n, coverage is C(n, n/2)

**Alternative (cleaner):** Show that for ANY Opt, if we pick I uniformly at
random from all size-k sets, a random pair fails to cover I with high prob.

Actually, the cleanest approach: **adversarial construction**.

### Step 7: Correct formulation of the lower bound

The counting argument is subtle. Here's the correct formulation:

**Key insight:** A certificate must work for ALL Opt functions. We show that
for any poly-size P, there exists an Opt such that P fails to refute it.

**Correct theorem statement:**

```lean
/-- For any polynomial-size set of pairs P, there exists an Opt function
    and a size-k set I such that:
    - I is NOT sufficient for Opt
    - No pair in P witnesses that I is not sufficient -/
theorem adversarial_Opt_exists (n : ℕ) (hn : 4 ≤ n)
    (P : Finset (BinaryState n × BinaryState n))
    (hP : P.card < 2 ^ (n / 2)) :  -- exponential slack
    ∃ (Opt : BinaryState n → Bool) (I : Finset (Fin n)),
      I.card = n / 2 ∧
      -- I is not sufficient for Opt
      (∃ s s', agreeOn s s' I ∧ Opt s ≠ Opt s') ∧
      -- P fails to witness insufficiency of I
      (∀ p ∈ P, agreeOn p.1 p.2 I → Opt p.1 = Opt p.2)
```

**Proof strategy:**
1. Total number of possible "witness pairs for I" = all (s,s') agreeing on I
2. That's 2^n × 2^(n - |I|) = 2^(2n - k) pairs (fix I-coords, vary rest)
3. Actually: pairs (s,s') with s|_I = s'|_I but s ≠ s'
4. For each I, there are (2^k) × (2^(n-k) × (2^(n-k) - 1)) ≈ 2^(2n-k) such pairs
5. P can cover at most |P| of these
6. If |P| < 2^(n-k), then for each I, P covers < 2^(n-k) pairs
7. There remain uncovered pairs for I → construct Opt from them

**Simpler approach:**
Pick I first, then construct Opt to defeat P on I.

```lean
theorem adversarial_for_fixed_I (n : ℕ) (I : Finset (Fin n))
    (hI : I.card < n)
    (P : Finset (BinaryState n × BinaryState n)) :
    ∃ Opt : BinaryState n → Bool,
      -- I is not sufficient
      (∃ s s', agreeOn s s' I ∧ Opt s ≠ Opt s') ∧
      -- P doesn't witness it
      (∀ p ∈ P, agreeOn p.1 p.2 I → Opt p.1 = Opt p.2) := by
  -- Construction: make P-pairs agree, pick one disagreeing pair for I
  -- Key: there exist s₀, s₁ agreeing on I with (s₀, s₁) ∉ P
  -- Set Opt(s₀) = false, Opt(s₁) = true, rest = true
  sorry
```

### Step 8: Key lemma - finding a pair outside P

For a fixed I with |I| < n, there are 2^(n - |I|) × (2^(n - |I|) - 1) / 2
pairs (s, s') with s ≠ s' but agreeOn s s' I. This is exponential in n - |I|.

If |P| < this count, there exists such a pair not in P.

```lean
lemma agreeing_pairs_count (n : ℕ) (I : Finset (Fin n)) :
    let m := n - I.card  -- coordinates outside I
    (Finset.filter (fun p : BinaryState n × BinaryState n =>
      agreeOn p.1 p.2 I ∧ p.1 ≠ p.2) Finset.univ).card =
    2 ^ I.card * (2 ^ m * (2 ^ m - 1))

lemma exists_pair_not_in_P (n : ℕ) (I : Finset (Fin n)) (hI : I.card < n)
    (P : Finset (BinaryState n × BinaryState n))
    (hP : P.card < 2 ^ (n - I.card)) :
    ∃ s s', agreeOn s s' I ∧ s ≠ s' ∧ (s, s') ∉ P ∧ (s', s) ∉ P
```

### Step 9: Construct Opt from the pair

```lean
/-- Given a pair (s₀, s₁) that agrees on I but differs, construct Opt
    such that Opt(s₀) ≠ Opt(s₁) but Opt is constant on all P-pairs -/
noncomputable def adversarialOpt'
    (P : Finset (BinaryState n × BinaryState n))
    (s₀ s₁ : BinaryState n) : BinaryState n → Bool :=
  -- Use union-find / equivalence closure of P
  -- Assign Opt(s) = (s in same component as s₀)
  fun s => decide (s = s₀)  -- simple version: only s₀ gets false

lemma adversarialOpt'_spec (P : Finset (BinaryState n × BinaryState n))
    (s₀ s₁ : BinaryState n) (hne : s₀ ≠ s₁)
    (hnotP : (s₀, s₁) ∉ P) (hnotP' : (s₁, s₀) ∉ P) :
    let Opt := adversarialOpt' P s₀ s₁
    Opt s₀ ≠ Opt s₁ ∧
    (∀ p ∈ P, Opt p.1 = Opt p.2 ∨ ¬(p.1 = s₀ ∨ p.2 = s₀))
```

### Step 10: Main theorem (corrected)

```lean
/-- For any set I with |I| < n and any P with |P| < 2^(n - |I|),
    there exists Opt such that I is not sufficient but P fails to witness it -/
theorem certificate_lower_bound_for_I (n : ℕ) (I : Finset (Fin n))
    (hI : I.card < n)
    (P : Finset (BinaryState n × BinaryState n))
    (hP : P.card < 2 ^ (n - I.card)) :
    ∃ Opt : BinaryState n → Bool,
      -- I is not sufficient for Opt
      (∃ s s', agreeOn s s' I ∧ Opt s ≠ Opt s') ∧
      -- For this I, no pair in P witnesses insufficiency
      (∀ p ∈ P, agreeOn p.1 p.2 I → Opt p.1 = Opt p.2)
```

**Corollary for poly-size P:**
When |I| = n/2, we need |P| < 2^(n/2). Any poly(n) satisfies this for large n.

```lean
theorem certificate_must_be_exponential (n : ℕ) (hn : 8 ≤ n)
    (I : Finset (Fin n)) (hI : I.card = n / 2)
    (P : Finset (BinaryState n × BinaryState n))
    (hP : P.card ≤ 2 ^ (n / 4)) :  -- poly(n) << 2^(n/4) << 2^(n/2)
    ∃ Opt : BinaryState n → Bool,
      (∃ s s', agreeOn s s' I ∧ Opt s ≠ Opt s') ∧
      (∀ p ∈ P, agreeOn p.1 p.2 I → Opt p.1 = Opt p.2)
```

### Step 11: Update Hardness.lean

Add import and summary theorem:
```lean
import DecisionQuotient.Hardness.CoveringLowerBound

/-- MINIMUM-SUFFICIENT-SET is not in coNP: for any polynomial-size
    "refutation certificate" P, there exists an Opt function that P
    fails to refute. -/
theorem minimum_sufficient_set_not_in_coNP_informal :
    ∀ (n : ℕ) (hn : 8 ≤ n) (I : Finset (Fin n)) (hI : I.card = n / 2)
      (P : Finset (BinaryState n × BinaryState n)) (hP : P.card ≤ 2^(n/4)),
    ∃ Opt, (∃ s s', agreeOn s s' I ∧ Opt s ≠ Opt s') ∧
           (∀ p ∈ P, agreeOn p.1 p.2 I → Opt p.1 = Opt p.2) :=
  fun n hn I hI P hP => certificate_must_be_exponential n hn I hI P hP
```

---

## Verification Checklist

After implementation, verify:
- [ ] `lake build` succeeds with no errors
- [ ] All `sorry` removed
- [ ] `certificate_lower_bound_for_I` theorem proven
- [ ] `certificate_must_be_exponential` corollary proven
- [ ] Imports added to `Hardness.lean`
- [ ] Documentation matches SIGMA2P_COMPLETENESS.md claims

---

## Summary of Mathematical Content

**What we're proving:**
For the complement of MINIMUM-SUFFICIENT-SET to be in NP, there must exist
polynomial-size certificates that verify "no small sufficient set exists."

**What a certificate would look like:**
For each candidate set I, a pair (s, s') with agreeOn s s' I but Opt(s) ≠ Opt(s').

**Why poly-size fails:**
For any poly-size set of pairs P and any candidate set I with |I| = n/2:
- There are 2^(n/2) pairs that agree on I and differ elsewhere
- P can contain at most poly(n) of them
- So there exists a pair (s₀, s₁) ∉ P that agrees on I
- Construct Opt with Opt(s₀) = 0, Opt(s₁) = 1
- Then I is not sufficient, but P doesn't witness it

**Conclusion:**
MINIMUM-SUFFICIENT-SET ∉ coNP (under standard complexity assumptions).

